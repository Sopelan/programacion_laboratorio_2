﻿public enum ETipoTrazo
{
    Fino,
    Grueso,
    Medio
}